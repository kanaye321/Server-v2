
import nodemailer from 'nodemailer';
import { storage } from './storage';

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

class EmailService {
  private transporter: nodemailer.Transporter | null = null;

  async initialize() {
    try {
      const settings = await storage.getSystemSettings();
      
      if (!settings?.mailHost || !settings?.mailFromAddress) {
        console.log('Email not configured - skipping email service initialization');
        return false;
      }

      this.transporter = nodemailer.createTransport({
        host: settings.mailHost,
        port: parseInt(settings.mailPort || '587'),
        secure: settings.mailPort === '465',
        auth: {
          user: settings.mailUsername || settings.mailFromAddress,
          pass: settings.mailPassword || ''
        }
      });

      // Verify connection
      await this.transporter.verify();
      console.log('✅ Email service initialized successfully');
      return true;
    } catch (error) {
      console.error('Failed to initialize email service:', error);
      this.transporter = null;
      return false;
    }
  }

  async sendEmail(options: EmailOptions): Promise<boolean> {
    if (!this.transporter) {
      console.log('📧 Email service not initialized - attempting to initialize...');
      const initialized = await this.initialize();
      if (!initialized) {
        console.log('❌ Cannot send email - service not configured. Please configure email settings in System Setup.');
        return false;
      }
    }

    try {
      const settings = await storage.getSystemSettings();
      
      console.log(`📧 Sending email...`);
      console.log(`   From: ${settings?.mailFromAddress}`);
      console.log(`   To: ${options.to}`);
      console.log(`   Subject: ${options.subject}`);
      
      const info = await this.transporter!.sendMail({
        from: `"${settings?.siteName || 'SRPH-MIS'}" <${settings?.mailFromAddress}>`,
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text || options.html.replace(/<[^>]*>/g, '')
      });

      console.log(`✅ Email sent successfully to ${options.to}`);
      console.log(`   Message ID: ${info.messageId}`);
      console.log(`   Response: ${info.response}`);
      return true;
    } catch (error: any) {
      console.error('❌ Failed to send email:', error.message);
      if (error.code) {
        console.error(`   Error code: ${error.code}`);
      }
      if (error.command) {
        console.error(`   Failed command: ${error.command}`);
      }
      return false;
    }
  }

  async sendIamExpirationNotification(data: {
    accounts: Array<{
      requestor: string;
      knoxId: string;
      permission: string;
      cloudPlatform: string;
      endDate: string;
      approvalId: string;
    }>;
  }) {
    try {
      const settings = await storage.getSystemSettings();
      
      if (!settings?.notifyOnIamExpiration) {
        console.log('📧 IAM expiration notifications are disabled');
        return false;
      }
      
      if (!settings?.companyEmail) {
        console.log('❌ No admin email configured for notifications');
        return false;
      }

      console.log(`📧 Preparing to send IAM expiration notification to: ${settings.companyEmail}`);
      console.log(`📧 ${data.accounts.length} expired IAM account(s)`);

      const subject = `[SRPH-MIS] IAM Account Expiration Alert - ${data.accounts.length} Account(s)`;
      
      const accountsHtml = data.accounts.map(account => `
        <tr>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${account.requestor}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${account.knoxId}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${account.permission}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${account.cloudPlatform}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${account.endDate}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb; font-weight: bold; color: #ef4444;">${account.approvalId}</td>
        </tr>
      `).join('');

      const html = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .header { background-color: #ef4444; color: white; padding: 20px; border-radius: 5px 5px 0 0; }
            .content { background-color: #f9fafb; padding: 20px; border: 1px solid #e5e7eb; }
            .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th { background-color: #f3f4f6; padding: 10px; border: 1px solid #e5e7eb; text-align: left; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h2>⚠️ IAM Account Expiration Alert</h2>
            </div>
            <div class="content">
              <p><strong>The following IAM accounts have expired and require attention:</strong></p>
              <table>
                <thead>
                  <tr>
                    <th>Requestor</th>
                    <th>Knox ID</th>
                    <th>Permission</th>
                    <th>Platform</th>
                    <th>End Date</th>
                    <th>Approval ID</th>
                  </tr>
                </thead>
                <tbody>
                  ${accountsHtml}
                </tbody>
              </table>
              <p><strong>Action Required:</strong></p>
              <ul>
                <li>Review and update expired accounts</li>
                <li>Contact requestors for extension if needed</li>
                <li>Remove access if no longer required</li>
                <li>Update status to "Expired - Notified" after notification</li>
              </ul>
              <p>This is an automated notification from SRPH-MIS.</p>
            </div>
            <div class="footer">
              <p>SRPH Management Information System</p>
              <p>This email was sent automatically. Please do not reply.</p>
            </div>
          </div>
        </body>
        </html>
      `;

      const result = await this.sendEmail({
        to: settings.companyEmail,
        subject,
        html
      });

      if (result) {
        console.log(`✅ IAM expiration notification sent successfully to ${settings.companyEmail}`);
      }

      return result;
    } catch (error) {
      console.error('❌ Error sending IAM expiration notification:', error);
      return false;
    }
  }

  async sendVmExpirationNotification(data: {
    vms: Array<{
      vmName: string;
      knoxId: string;
      requestor: string;
      department: string;
      endDate: string;
      approvalNumber: string;
    }>;
  }) {
    try {
      const settings = await storage.getSystemSettings();
      
      if (!settings?.notifyOnVmExpiration) {
        console.log('📧 VM expiration notifications are disabled');
        return false;
      }
      
      if (!settings?.companyEmail) {
        console.log('❌ No admin email configured for notifications');
        return false;
      }

      console.log(`📧 Preparing to send VM expiration notification to: ${settings.companyEmail}`);
      console.log(`📧 ${data.vms.length} expired VM(s)`);

      const subject = `[SRPH-MIS] VM Expiration Alert - ${data.vms.length} Virtual Machine(s)`;
      
      const vmsHtml = data.vms.map(vm => `
        <tr>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${vm.vmName}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${vm.knoxId || 'N/A'}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${vm.requestor}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${vm.department || 'N/A'}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb;">${vm.endDate}</td>
          <td style="padding: 10px; border: 1px solid #e5e7eb; font-weight: bold; color: #ef4444;">${vm.approvalNumber || 'N/A'}</td>
        </tr>
      `).join('');

      const html = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .header { background-color: #ef4444; color: white; padding: 20px; border-radius: 5px 5px 0 0; }
            .content { background-color: #f9fafb; padding: 20px; border: 1px solid #e5e7eb; }
            .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th { background-color: #f3f4f6; padding: 10px; border: 1px solid #e5e7eb; text-align: left; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h2>⚠️ Virtual Machine Expiration Alert</h2>
            </div>
            <div class="content">
              <p><strong>The following virtual machines have reached their end date and require attention:</strong></p>
              <table>
                <thead>
                  <tr>
                    <th>VM Name</th>
                    <th>Knox ID</th>
                    <th>Requestor</th>
                    <th>Department</th>
                    <th>End Date</th>
                    <th>Approval Number</th>
                  </tr>
                </thead>
                <tbody>
                  ${vmsHtml}
                </tbody>
              </table>
              <p><strong>Action Required:</strong></p>
              <ul>
                <li>Review and update expired VMs</li>
                <li>Contact requestors for extension if needed</li>
                <li>Decommission VMs if no longer required</li>
                <li>Update status to "Overdue - Notified" after notification</li>
              </ul>
              <p>This is an automated notification from SRPH-MIS.</p>
            </div>
            <div class="footer">
              <p>SRPH Management Information System</p>
              <p>This email was sent automatically. Please do not reply.</p>
            </div>
          </div>
        </body>
        </html>
      `;

      const result = await this.sendEmail({
        to: settings.companyEmail,
        subject,
        html
      });

      if (result) {
        console.log(`✅ VM expiration notification sent successfully to ${settings.companyEmail}`);
      }

      return result;
    } catch (error) {
      console.error('❌ Error sending VM expiration notification:', error);
      return false;
    }
  }

  async sendModificationNotification(data: {
    action: string;
    itemType: string;
    itemName: string;
    userName: string;
    details: string;
    timestamp: string;
  }) {
    try {
      const settings = await storage.getSystemSettings();
      
      // Check if notifications are enabled
      if (!settings?.enableAdminNotifications) {
        console.log('📧 Email notifications are disabled in system settings');
        return false;
      }
      
      if (!settings?.companyEmail) {
        console.log('❌ No admin email configured for notifications');
        return false;
      }

      console.log(`📧 Preparing to send email notification to: ${settings.companyEmail}`);
      console.log(`📧 Notification type: ${data.action} - ${data.itemType}`);

      const subject = `[SRPH-MIS] ${data.action.toUpperCase()} - ${data.itemType}`;
      
      const html = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #2563eb; color: white; padding: 20px; border-radius: 5px 5px 0 0; }
            .content { background-color: #f9fafb; padding: 20px; border: 1px solid #e5e7eb; }
            .details { background-color: white; padding: 15px; margin: 10px 0; border-left: 4px solid #2563eb; }
            .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
            .action-badge { display: inline-block; padding: 5px 10px; border-radius: 3px; font-weight: bold; }
            .action-create { background-color: #10b981; color: white; }
            .action-update { background-color: #f59e0b; color: white; }
            .action-delete { background-color: #ef4444; color: white; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h2>🔔 System Modification Alert</h2>
            </div>
            <div class="content">
              <p>A modification has been made in the system:</p>
              <div class="details">
                <p><strong>Action:</strong> <span class="action-badge action-${data.action.toLowerCase()}">${data.action.toUpperCase()}</span></p>
                <p><strong>Item Type:</strong> ${data.itemType}</p>
                <p><strong>Item Name:</strong> ${data.itemName}</p>
                <p><strong>Modified By:</strong> ${data.userName}</p>
                <p><strong>Details:</strong> ${data.details}</p>
                <p><strong>Timestamp:</strong> ${new Date(data.timestamp).toLocaleString()}</p>
              </div>
              <p>This is an automated notification from SRPH-MIS.</p>
            </div>
            <div class="footer">
              <p>SRPH Management Information System</p>
              <p>This email was sent automatically. Please do not reply.</p>
            </div>
          </div>
        </body>
        </html>
      `;

      const result = await this.sendEmail({
        to: settings.companyEmail,
        subject,
        html
      });

      if (result) {
        console.log(`✅ Email notification sent successfully to ${settings.companyEmail}`);
      } else {
        console.log(`⚠️ Email notification failed to send`);
      }

      return result;
    } catch (error) {
      console.error('❌ Error sending modification notification:', error);
      return false;
    }
  }
}

export const emailService = new EmailService();
