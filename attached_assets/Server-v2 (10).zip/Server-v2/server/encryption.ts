
import crypto from 'crypto';

// Encryption configuration
const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const SALT_LENGTH = 64;
const TAG_LENGTH = 16;
const KEY_LENGTH = 32;
const ITERATIONS = 100000;

// Get or generate encryption key from environment
function getEncryptionKey(): Buffer {
  const envKey = process.env.ENCRYPTION_KEY;
  
  if (!envKey) {
    console.warn('⚠️ ENCRYPTION_KEY not set in environment variables. Using fallback key (NOT SECURE FOR PRODUCTION)');
    // Generate a consistent key from a seed for development
    return crypto.pbkdf2Sync('default-development-key', 'salt', ITERATIONS, KEY_LENGTH, 'sha512');
  }
  
  // Derive key from environment variable
  return crypto.pbkdf2Sync(envKey, 'srph-mis-salt', ITERATIONS, KEY_LENGTH, 'sha512');
}

/**
 * Encrypt sensitive data
 * @param text - Plain text to encrypt
 * @returns Encrypted string in format: iv:encrypted:authTag
 */
export function encrypt(text: string | null | undefined): string | null {
  if (!text || text.trim() === '') {
    return null;
  }

  try {
    const key = getEncryptionKey();
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
    
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    
    // Return format: iv:encrypted:authTag
    return `${iv.toString('hex')}:${encrypted}:${authTag.toString('hex')}`;
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
}

/**
 * Decrypt sensitive data
 * @param encryptedText - Encrypted string in format: iv:encrypted:authTag
 * @returns Decrypted plain text
 */
export function decrypt(encryptedText: string | null | undefined): string | null {
  if (!encryptedText || encryptedText.trim() === '') {
    return null;
  }

  try {
    // Check if data is already in plain text (backward compatibility)
    if (!encryptedText.includes(':')) {
      console.warn('⚠️ Data appears to be unencrypted, returning as-is');
      return encryptedText;
    }

    const parts = encryptedText.split(':');
    if (parts.length !== 3) {
      console.warn('⚠️ Invalid encrypted data format, returning as-is');
      return encryptedText;
    }

    const [ivHex, encrypted, authTagHex] = parts;
    
    const key = getEncryptionKey();
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data');
  }
}

/**
 * Encrypt an object's sensitive fields
 * @param data - Object with sensitive fields
 * @param fields - Array of field names to encrypt
 * @returns Object with encrypted fields
 */
export function encryptFields<T extends Record<string, any>>(
  data: T,
  fields: (keyof T)[]
): T {
  const encrypted = { ...data };
  
  for (const field of fields) {
    if (encrypted[field] && typeof encrypted[field] === 'string') {
      encrypted[field] = encrypt(encrypted[field] as string) as any;
    }
  }
  
  return encrypted;
}

/**
 * Decrypt an object's sensitive fields
 * @param data - Object with encrypted fields
 * @param fields - Array of field names to decrypt
 * @returns Object with decrypted fields
 */
export function decryptFields<T extends Record<string, any>>(
  data: T,
  fields: (keyof T)[]
): T {
  const decrypted = { ...data };
  
  for (const field of fields) {
    if (decrypted[field] && typeof decrypted[field] === 'string') {
      decrypted[field] = decrypt(decrypted[field] as string) as any;
    }
  }
  
  return decrypted;
}

/**
 * Hash sensitive data (one-way, for comparison purposes)
 * @param text - Text to hash
 * @returns Hashed string
 */
export function hash(text: string): string {
  return crypto.createHash('sha256').update(text).digest('hex');
}

/**
 * Generate a secure random encryption key
 * @returns Base64 encoded encryption key
 */
export function generateEncryptionKey(): string {
  return crypto.randomBytes(32).toString('base64');
}

// PII field definitions for different entities
export const PII_FIELDS = {
  user: ['email', 'firstName', 'lastName', 'department'],
  asset: ['knoxId', 'serialNumber', 'macAddress', 'ipAddress'],
  bitlockerKey: ['serialNumber', 'identifier', 'recoveryKey'],
  consumable: ['serialNumber', 'modelNumber'],
  accessory: ['serialNumber', 'knoxId'],
  component: ['serialNumber'],
  license: ['key'],
  vmInventory: ['knoxId', 'requestor', 'vmIp', 'ipAddress', 'macAddress'],
  iamAccount: ['knoxId', 'requestor'],
  itEquipment: ['knoxId', 'serialNumber'],
  monitor: ['knoxId', 'assetNumber', 'serialNumber']
} as const;
