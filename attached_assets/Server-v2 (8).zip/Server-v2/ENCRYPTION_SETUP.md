
# PII Encryption Setup Guide

This guide explains how to set up and use the PII encryption feature in SRPH-MIS.

## Overview

The system now encrypts all Personally Identifiable Information (PII) at rest using AES-256-GCM encryption. This includes:

- **User Data**: Email, first name, last name, department
- **Asset Data**: Knox IDs, serial numbers, MAC addresses, IP addresses
- **BitLocker Keys**: Serial numbers, identifiers, recovery keys
- **VM Inventory**: Knox IDs, requestor info, IP addresses
- **IAM Accounts**: Knox IDs, requestor information
- **Equipment**: Knox IDs, serial numbers

## Setup Instructions

### 1. Generate Encryption Key

Generate a secure encryption key using the Secrets tool:

1. Open your Repl
2. Navigate to **Tools** → **Secrets**
3. Click **+ New Secret**
4. Set the key name as: `ENCRYPTION_KEY`
5. Generate a secure random value (32+ characters recommended)
6. Click **Add Secret**

**Example**: You can generate a key using Node.js:
```javascript
require('crypto').randomBytes(32).toString('base64')
```

### 2. Restart Your Application

After adding the encryption key, restart your Repl for the changes to take effect.

### 3. Encrypt Existing Data (One-Time Migration)

If you have existing data that needs to be encrypted:

```bash
npm run encrypt-data
```

Or run directly:
```bash
node -r esbuild-register server/encrypt-existing-data.ts
```

## Security Best Practices

1. **Never commit the encryption key** to version control
2. **Store the key securely** in Replit Secrets or a secure key management service
3. **Rotate keys periodically** (every 90 days recommended)
4. **Backup encrypted data** before key rotation
5. **Limit access** to the encryption key to authorized personnel only

## How It Works

### Encryption Process
1. When PII is stored, it's encrypted using AES-256-GCM
2. Each field is encrypted with a unique IV (Initialization Vector)
3. An authentication tag ensures data integrity
4. Encrypted format: `iv:encrypted_data:auth_tag`

### Decryption Process
1. Data is automatically decrypted when retrieved
2. The system verifies the authentication tag
3. If verification fails, an error is thrown
4. Backward compatibility: Unencrypted data is returned as-is

## Encrypted Fields

### Users
- `email`
- `firstName`
- `lastName`
- `department`

### Assets
- `knoxId`
- `serialNumber`
- `macAddress`
- `ipAddress`

### BitLocker Keys
- `serialNumber`
- `identifier`
- `recoveryKey` (most critical)

### VM Inventory
- `knoxId`
- `requestor`
- `vmIp`
- `ipAddress`
- `macAddress`

### IAM Accounts
- `knoxId`
- `requestor`

### IT Equipment
- `knoxId`
- `serialNumber`

### Monitor Inventory
- `knoxId`
- `assetNumber`
- `serialNumber`

## Troubleshooting

### "Encryption key not set" Warning
- Add `ENCRYPTION_KEY` to your Secrets
- Restart the application

### Decryption Errors
- Verify the encryption key hasn't changed
- Check if data format is correct (should contain colons)
- Review server logs for specific error details

### Migration Issues
- Ensure database connection is active
- Check that you have write permissions
- Verify no concurrent access during migration

## Compliance

This encryption implementation helps meet compliance requirements for:
- GDPR (General Data Protection Regulation)
- CCPA (California Consumer Privacy Act)
- SOC 2 Type II
- ISO 27001

## Support

For issues or questions about encryption:
1. Check server logs for detailed error messages
2. Review the encryption utility in `server/encryption.ts`
3. Contact your system administrator
