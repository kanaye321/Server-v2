
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Mail, Send, Settings, CheckCircle, AlertCircle, Loader2 } from "lucide-react";

export default function EmailNotificationsPage() {
  const { toast } = useToast();
  const [isTesting, setIsTesting] = useState(false);

  const { data: settings, isLoading } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/settings');
      return response.json();
    }
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/settings', data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      toast({
        title: "Settings saved",
        description: "Email notification settings have been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save email settings. Please try again.",
        variant: "destructive",
      });
    }
  });

  const testEmailMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/test-email');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Test email sent",
        description: data.message || "Check your inbox for the test email.",
      });
      setIsTesting(false);
    },
    onError: (error: any) => {
      toast({
        title: "Test email failed",
        description: error.message || "Could not send test email. Please check your configuration.",
        variant: "destructive",
      });
      setIsTesting(false);
    }
  });

  const handleSaveSettings = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const settingsData = {
      mailHost: formData.get('mailHost')?.toString() || '',
      mailPort: formData.get('mailPort')?.toString() || '587',
      mailUsername: formData.get('mailUsername')?.toString() || '',
      mailPassword: formData.get('mailPassword')?.toString() || '',
      mailFromAddress: formData.get('mailFromAddress')?.toString() || '',
      mailFromName: formData.get('mailFromName')?.toString() || settings?.siteName || 'SRPH-MIS',
      companyEmail: formData.get('companyEmail')?.toString() || '',
      enableAdminNotifications: formData.get('enableAdminNotifications') === 'on',
      notifyOnCheckin: formData.get('notifyOnCheckin') === 'on',
      notifyOnCheckout: formData.get('notifyOnCheckout') === 'on',
      notifyOnIamExpiration: formData.get('notifyOnIamExpiration') === 'on',
      notifyOnVmExpiration: formData.get('notifyOnVmExpiration') === 'on',
    };

    console.log('Saving email settings:', settingsData);
    updateSettingsMutation.mutate(settingsData);
  };

  const handleTestEmail = () => {
    setIsTesting(true);
    testEmailMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader 
        title="Email Notifications" 
        description="Configure email notifications for system modifications and events"
      >
        <Button onClick={handleTestEmail} disabled={isTesting} variant="outline">
          {isTesting ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Send className="h-4 w-4 mr-2" />
          )}
          Send Test Email
        </Button>
      </PageHeader>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              SMTP Configuration
            </CardTitle>
            <CardDescription>
              Configure your email server settings to enable email notifications
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="mailHost">SMTP Server</Label>
                <Input
                  id="mailHost"
                  name="mailHost"
                  placeholder="smtp.gmail.com"
                  defaultValue={settings?.mailHost || ''}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mailPort">SMTP Port</Label>
                <Input
                  id="mailPort"
                  name="mailPort"
                  type="number"
                  placeholder="587"
                  defaultValue={settings?.mailPort || '587'}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="mailUsername">SMTP Username</Label>
                <Input
                  id="mailUsername"
                  name="mailUsername"
                  placeholder="your-email@example.com"
                  defaultValue={settings?.mailUsername || ''}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mailPassword">SMTP Password</Label>
                <Input
                  id="mailPassword"
                  name="mailPassword"
                  type="password"
                  placeholder="••••••••"
                  defaultValue={settings?.mailPassword || ''}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="mailFromAddress">From Email Address</Label>
                <Input
                  id="mailFromAddress"
                  name="mailFromAddress"
                  type="email"
                  placeholder="noreply@example.com"
                  defaultValue={settings?.mailFromAddress || ''}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mailFromName">From Name</Label>
                <Input
                  id="mailFromName"
                  name="mailFromName"
                  placeholder="SRPH-MIS"
                  defaultValue={settings?.mailFromName || settings?.siteName || 'SRPH-MIS'}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="companyEmail">Admin Email (Receives Notifications)</Label>
              <Input
                id="companyEmail"
                name="companyEmail"
                type="email"
                placeholder="admin@example.com"
                defaultValue={settings?.companyEmail || ''}
              />
              <p className="text-sm text-muted-foreground">
                This email will receive all system modification notifications
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Notification Preferences
            </CardTitle>
            <CardDescription>
              Choose which events trigger email notifications
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label className="text-base">Enable Email Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Send email alerts for system modifications
                </p>
              </div>
              <Switch
                name="enableAdminNotifications"
                defaultChecked={settings?.enableAdminNotifications || false}
              />
            </div>

            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label className="text-base">Asset Check-out Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Alert when assets are checked out
                </p>
              </div>
              <Switch
                name="notifyOnCheckout"
                defaultChecked={settings?.notifyOnCheckout || false}
              />
            </div>

            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label className="text-base">Asset Check-in Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Alert when assets are checked in
                </p>
              </div>
              <Switch
                name="notifyOnCheckin"
                defaultChecked={settings?.notifyOnCheckin || false}
              />
            </div>

            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label className="text-base">IAM Account Expiration Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Alert when IAM accounts expire (daily check)
                </p>
              </div>
              <Switch
                name="notifyOnIamExpiration"
                defaultChecked={settings?.notifyOnIamExpiration !== false}
              />
            </div>

            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label className="text-base">VM Expiration Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Alert when VMs reach end date (daily check)
                </p>
              </div>
              <Switch
                name="notifyOnVmExpiration"
                defaultChecked={settings?.notifyOnVmExpiration !== false}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              IAM Account Expiration Email Template
            </CardTitle>
            <CardDescription>
              Customize the email sent to IAM account owners when their accounts expire
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="iamExpirationEmailSubject">Email Subject</Label>
              <Input
                id="iamExpirationEmailSubject"
                name="iamExpirationEmailSubject"
                placeholder="IAM Account Access Expiration Notice"
                defaultValue={settings?.iamExpirationEmailSubject || 'IAM Account Access Expiration Notice'}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="iamExpirationEmailBody">Email Body</Label>
              <p className="text-sm text-muted-foreground">
                Use these placeholders: {'{'}removalDate{'}'}, {'{'}requestor{'}'}, {'{'}knoxId{'}'}, {'{'}permission{'}'}, {'{'}cloudPlatform{'}'}, {'{'}endDate{'}'}, {'{'}approvalId{'}'}
              </p>
              <textarea
                id="iamExpirationEmailBody"
                name="iamExpirationEmailBody"
                className="w-full min-h-[300px] p-3 border rounded-md font-mono text-sm"
                defaultValue={settings?.iamExpirationEmailBody || `Hi,

Please be advised that your requested access is now expired and will be removed on {removalDate}.

Kindly let us know if you still require access or if we can now proceed with the removal.

https://confluence.sec.samsung.net/pages/viewpage.action?pageId=454565479&spaceKey=SRPHCOMMONC&title=AWS%2BApproval%2BGuide

Account Details:
- Requestor: {requestor}
- Knox ID: {knoxId}
- Permission/IAM/SCOP: {permission}
- Cloud Platform: {cloudPlatform}
- Expiration Date: {endDate}
- Approval ID: {approvalId}

If you need to extend your access, please submit a new request through the proper channels.`}
              />
            </div>

            <div className="rounded-lg bg-muted p-4">
              <h4 className="font-medium mb-2">Available Placeholders:</h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li><code className="bg-background px-1 py-0.5 rounded">{'{'}removalDate{'}'}</code> - Date when access will be removed (7 days from now)</li>
                <li><code className="bg-background px-1 py-0.5 rounded">{'{'}requestor{'}'}</code> - Name of the person who requested the account</li>
                <li><code className="bg-background px-1 py-0.5 rounded">{'{'}knoxId{'}'}</code> - Knox ID of the account owner</li>
                <li><code className="bg-background px-1 py-0.5 rounded">{'{'}permission{'}'}</code> - Permission/IAM/SCOP details</li>
                <li><code className="bg-background px-1 py-0.5 rounded">{'{'}cloudPlatform{'}'}</code> - Cloud platform (AWS, Azure, etc.)</li>
                <li><code className="bg-background px-1 py-0.5 rounded">{'{'}endDate{'}'}</code> - Original expiration date</li>
                <li><code className="bg-background px-1 py-0.5 rounded">{'{'}approvalId{'}'}</code> - Approval ID number</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={updateSettingsMutation.isPending}>
            {updateSettingsMutation.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <CheckCircle className="h-4 w-4 mr-2" />
            )}
            Save Settings
          </Button>
        </div>
      </form>

      <Card>
        <CardHeader>
          <CardTitle>Email Notification Events</CardTitle>
          <CardDescription>
            Emails are automatically sent for the following events:
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Asset creation, updates, and deletions</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>User account creation and modifications</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>License assignments and changes</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Component and consumable inventory updates</span>
            </li>
            <li className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-amber-500" />
              <span>IAM account expirations (checked daily)</span>
            </li>
            <li className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-amber-500" />
              <span>VM inventory expirations (checked daily)</span>
            </li>
            <li className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-amber-500" />
              <span>System alerts and critical events</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
